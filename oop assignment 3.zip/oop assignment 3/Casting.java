/*class Casting
{
public static void main(String args[])
{
         int i = 9;
    double  d =  i;                  // int to double     widening conversion

    System.out.println("i = "+i);      // Outputs 9
    System.out.println("d = " +d);        // Outputs 9.0
  }
}   */


class Casting
{
public static void main(String args[])
{
 
    double d = 9.78;
    int i = (int) d;                                                //double to int   Narrowing   conversion

    System.out.println("d = "+d);                           // Outputs 9.78
    System.out.println("i = " +i);                          // Outputs 9
  }
}

