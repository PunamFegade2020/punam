import java.util.*;
class Array11
{
	public static void main(String[] args) 
	{
		int i, n;
		Scanner sc = new Scanner(System.in);
	 
		System.out.print(" Enter  Number of elements in an array : ");
		n = sc.nextInt();	
		
		int [] arr = new int[n];
		
		System.out.print("  Enter " +  n  + " elements of an Array  : ");
		for (i = 0; i < n; i++)
		{
			arr[i] = sc.nextInt();
		}     
	 
		System.out.println(" Array   Element are :  ");
		for (i = 0; i < n; i++)
		{
			System.out.print(arr[i] );
                                                     System.out.println( );
		}
	}
}