class  ArmstrongNo
{
public static void main(String args[])
{
int no=371, originalNumber, rem, result=0;
originalNumber=no;

while(originalNumber !=0)
{
   rem= originalNumber % 10;
  result += Math.pow(rem,3);
 originalNumber /= 10;
}
 if( result == no)

   System.out.println(no+" is an armstrong number : ");
else
System.out.println(no+" is not an armstrong number : ");
}
}