class Datatype
{
int i;
float f;
long l;
double d;
byte by;
boolean b;
short sh;

void display()
{
System.out.println("Default value of int = "  +i);

System.out.println("Default value of float = "  +f);

System.out.println("Default value of  long = "  +l);

System.out.println("Default value of double = "  +d);

System.out.println("Default value of byte = "  +by);

System.out.println("Default value of boolean = "  +b);

System.out.println("Default value of short = "  +sh);

}
public static void main(String args[])
{
Datatype d = new Datatype();
d.display();
}
}

