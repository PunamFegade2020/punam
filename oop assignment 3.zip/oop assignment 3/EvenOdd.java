import java.util.Scanner;

class EvenOdd
 {
	private static Scanner sc;
	
	public static void main(String[] args)
 {
		int Number;
		sc = new Scanner(System.in);		
		System.out.println(" Enter any  number : ");
		Number = sc.nextInt();
		
		if (Number % 2 == 0)
                                      {
	                           System.out.println("EVEN Number");
		}
		else {
			System.out.println(" ODD Number");
		}
	}
}