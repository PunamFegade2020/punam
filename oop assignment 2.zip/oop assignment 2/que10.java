class que10
{
public static void main(String  args[])
{
int  sum=0;
int temp=0;

int a []={2,3,4,5,6,7,8,9,10};

for(int i=0;i<a.length;i++)
{
   if(a[i] %2 == 0)
{
  sum=sum+a[i];
}
  else
{
  temp = temp+ a[i];
}

}
 System.out.println("Sum of even :  "+sum);
 System.out.println("Sum of odd :  "+temp);
 }
}