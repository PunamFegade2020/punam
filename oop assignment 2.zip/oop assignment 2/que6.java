import java.util.Scanner;
class que6
{
public static void main (String args[])
{
 Scanner sc=new Scanner(System.in);
 int[] a =new int[10]; 

int sum=0;
System.out.println("Enter the array elements");
for(int i=0; i<10; i++)
{
 a[i]=sc.nextInt();             //get input from user
}
for(int i=0; i<10; i++)
{
 sum=sum+a[i];    
  
}
System.out.println("Sum of array element :"+sum);
double avg = sum / 10;  
System.out.println("Average of array element : "+avg);
}
}