import java.util.*;
class que7
{
	public static void main(String[] args) 
	{
		int  temp;
		Scanner s = new Scanner(System.in);

                                     int a[] = new int[10]; 
	                 System.out.println("Enter a array element :");
		for (int i = 0; i < 10; i++) 
		{
			a[i] = s.nextInt();
		}

		//sorting elements
		for (int i = 0; i < 10; i++) 
		{
			for (int j = i + 1; j < 10; j++) 
			{
			if (a[i] < a[j]) 
			{
			       temp = a[i];
			     a[i] = a[j];
		                      a[j] = temp;
		                }
		            }
		}

		//print sorted array
		System.out.println("Descending Order:");
		for (int i = 0; i < 10; i++) 
		{
			System.out.println(a[i]);
		}
	}
}