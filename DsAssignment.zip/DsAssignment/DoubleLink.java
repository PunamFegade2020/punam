package DsAssignment;
class Node
{
	int data;
	Node fLink;
	Node bLink;
	Node(int data)
	{
		this.data=data;
		this.fLink=this.bLink=null;
	}
}
public class DoubleLink 
{
Node start;
int length;
DoubleLink()
{
	this.start=null;
	this.length=0;
}
public void insertBeg(int data) 
{
	Node newNode=new Node(data);
	if(start == null)
	{
		start = newNode;
	}
	else {
		start.bLink=newNode;
		newNode.fLink=start;
		start=newNode;
	}
	length++;
}
public void insertEnd(int data) {
	Node newNode =new Node(data);
	if(start==null)
	{
		start=newNode;
	}
		else
		{
			Node n=start;
			while(n.fLink !=null)
			{
				n=n.fLink;
			}
			n.fLink=newNode;
			newNode.bLink = n;
		}
	length++;
}
public void insertPos(int data,int pos) 
{
	if(pos==1)
	{
		insertBeg(data);
	}
	else if(pos > length)
	{
		insertEnd(data);
	}
	else
	{
		int i=1;
		Node n=start;
		while(n.fLink != null)
		{
			i++;
			if(i==pos)
				break;
			n=n.fLink;
		}
		Node newNode =new Node(data);
		newNode.bLink=n;
		newNode.fLink=n.fLink;
		n.fLink.bLink=newNode;
		n.fLink=newNode;
		
		length++;
	}
}

public void deleteBeg() 
{
Node n=start;
if(start == null)
{
	System.out.println("List Empty");
}
else
{
	start = n.fLink;
	start.bLink = null;
}
length--;
}
public void deletepos(int pos) 
{
	if(pos < 0)
	{
		System.out.println("Pos does not");
		return;
	}
	if(pos == 1)
	{
		deleteBeg();
	}
	else if(pos>length)
	{
		deleteEnd();
	}
	else
	{
	  int i=1;
	  Node p=start;
	  
	  while(p.fLink != null)
	  {
		  i++;
		  if(i == pos)
			  break;
		  p=p.fLink;
	  }
	  p.fLink.fLink.bLink = p;
	  p.fLink=p.fLink.fLink;
	  length--;
	}
}
public void deleteEnd() 
{
if(start == null)
{
	System.out.println("list empty");
}
else
{
	Node n=start;
	while(n.fLink.fLink !=null)
	{
		n=n.fLink;
	}
	n.fLink.bLink=null;
	n.fLink=null;
	length--;
}
}

public void displayForward() 
{
   Node n=start;
   while(n.fLink !=null)
   {
	   System.out.print(n.data +" ->");
	   n=n.fLink;
   }
   System.out.print(n.data + " ");
}
public void displayBackward() 
{
    Node n=start;
    while(n.fLink != null)
    {
    	n=n.fLink;
    }
    while(n.bLink !=null)
    {
    	System.out.print(n.data + " <- ");
    	n=n.bLink;
    }
    System.out.println(n.data + " ");
}

public static void main(String args[])
{
	DoubleLink dl=new DoubleLink();
	dl.insertBeg(10);
	dl.insertBeg(20);
	dl.insertBeg(30);
                dl.insertBeg(70);
	dl.insertEnd(40);
	
	dl.insertPos(2,4);
	dl.displayForward();
	System.out.println();
	
	dl.deleteEnd();
	dl.deleteBeg();
	dl.displayForward();
	System.out.println();
	dl.displayBackward();
	}
}
