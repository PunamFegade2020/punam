package DsAssignment;
import java.util.Scanner;
public class MultipleBracket
{
	GenericStack s=new GenericStack();
	Scanner sc=new Scanner(System.in);
String str;
void setInput()
{
	int roundp=0;
	int roundc=0;
	int squarep=0;
	int squarec=0;
	int kcountp=0;
	int kcountc=0;
	str=sc.nextLine();
	char ch[]=str.toCharArray();
  
	for(int i=0;i<ch.length;i++)
	{
	
	if(ch[i]=='{')
	{
		s.push(ch[i]);
		roundp++;
	}
	if(s.peek()=='{'&&ch[i]=='}')
		{
		s.pop();
		roundc++;
		}
		else if(ch[i]=='}') {
			roundc++;
		}
		
	if(ch[i]=='[')
	{
		s.push(ch[i]);
		squarep++;
	}	
		if(s.peek()==']'&&ch[i]==']')
		{
		s.pop();
		squarec++;
		}
		else if(ch[i]==']') {
			squarec++;
		}
		
	if(ch[i]=='(')
	{
		s.push(ch[i]);
		kcountp++;
	}
		if(s.peek()=='('&&ch[i]==')')
		{
		s.pop();
		kcountc++;
		}
		else if(ch[i]==')') {
			kcountc++;
		}
	}
		
	System.out.print(kcountc);
	
	if(roundp==roundc&&squarep==squarec&&kcountp==kcountc) 
                   {
		System.out.println("Balance");
	}
	else
                   {
		System.out.println("Not Balance");
	}
 }
	public static void main(String[] args)
        {
		MultipleBracket p=new MultipleBracket();
		p.setInput();
        }
}


