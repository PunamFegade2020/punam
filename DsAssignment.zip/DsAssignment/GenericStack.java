package DsAssignment;
public class GenericStack
{
	public static final int max=30;
	char a[]=new char[max];
	int Top;
	GenericStack()
	{
		Top=-1;
	}
	boolean isEmpty()
	{
		if(Top<0)
		{
			
		return true;
		}
		return false;
		
	}
	boolean isFull()
	{
		if(Top>=(max-1))
		{

			return true;
		}
		return false;
	}
	
	void push(char ab)
	{
		if(isFull())
		{
			System.out.println("Stack is overflow");
			
		}
		else {
				
				a[++Top]=ab;
		}
		
	}
	
	void pop()
	{
		if(isEmpty())
		{
		 
		  System.out.println("Stack is underflow(Empty)");
		}
		else 
                                      {
			 int m=a[Top--];
		}
	}
	
	char peek()
	{
		if(isEmpty())
		{
			System.out.println("stack is Underflow");
		}
		else {
		return a[Top];
		}
		return 'n';
	}
}
