    package DsAssignmen;
    public class StackLinkList {
    static class Node{
            int data;
            Node next;
            Node(int data)
            {
                    this.data=data;
            }

    }
    Node Top;
    StackLinkList()
    {
            this.Top=null;
    }

    public boolean isEmpty()
    {
            return Top==null;
     }

    public void push(int data)
    {

            Node temp=new Node(data);
            if(temp==null)
            {
                    System.out.println("heap overflow");
                    return;
            }

            //temp.data=data;
            temp.next=Top;
            Top=temp;
  }

    public  void pop()
    {
    if(Top==null)
    {
            System.out.println("heap underflow");
    }
    Top=Top.next;
    }

 public void display() 
    { 
        if (Top == null) 
        { 
            System.out.println("\nStack Underflow"); 
        } 
        else { 
            Node temp = Top; 
            while (temp != null) { 


                System.out.print("->"+temp.data); 
                temp = temp.next; 
                System.out.print("");
            } 
        } 
    } 	public static void main(String[] args) {
                   StackLinkList obj=new StackLinkList();
            obj.push(11); 
            obj.push(22); 
            obj.push(33); 
            obj.push(44); 
            
            obj.display(); 
            obj.pop();
            System.out.println();
            obj.display(); 
            }
 }
