package DsAssignment;

	class Node1
	{
	    int data;
	    Node1 next;
	    Node1 tail;
	}
	class SingleLink
	{
	    Node1 head;
	    
	    Node1 tail=null;
	    void insert(int data)
	    {
	        Node1 nd=new Node1();
	        nd.data=data;
	        nd.next=null;
	        if(head==null)
	        {
	            head=nd;
	        }
	        else
	        {
	            Node1 n=head;
	            while(n.next!=null)
	            {
	              n=n.next;  
	            }
	            n.next=nd;
	        }
	    }
	    void insertbeg(int data)
	    {
	        Node1 nd=new Node1();
	        nd.data=data;
	        nd.next=null;
	        nd.next=head;
	        head=nd;
	    }
	    void insertAt(int index,int data)
	    {
	       
	        Node1 nd=new Node1();
	        nd.data=data;
	        nd.next=null;
	        if(index==0)
	        {
	            insertbeg(data);
	        }
	        Node1 n=head;
	        for(int i=0;i<index-1;i++)
	        {
	            n=n.next;
	        }
	        nd.next=n.next;
	        n.next=nd;
	    }
	    void insertAtend(int data)
	    {
	        Node1 nd=new Node1();
	        nd.data=data;
	        if(head==null)
	        {
	            head=nd;
	        }
	        else
	        {
	        Node1 n=head;
	        while(n.next!=null)
	           n=n.next;
	        n.next=nd;
	        }   
	    }
	    void deleteAtbeg()
	    {
	        if(head==null)
	        {
	            System.out.println("List is empty");
	        return;
	        }
	        else
	        {
	            if(tail != null)
	            {
	                head=head.next;
	            }
	            else
	            {
	                head=tail=null;
	            }
	        }
	        
	    }
	    void deleteAt(int index)
	    {
	        if(index==0)
	        {
	            head=head.next;
	        }
	        else
	        {
	            Node1 n=head;
	            Node1 n1=null;
	            for(int i=0;i<index-1;i++)
	            {
	                n=n.next;
	            }
	            n1=n.next;
	            n.next=n1.next;
	            System.out.println("n1"+n1.data);
	            n1=null;
	        }
	    }
	    void deleteAtLast()
	    {
	        if(head==null)
	        {
	            System.out.println("list is empty");
	        }
	        Node1 n=head;
	        while(n.next.next!=null)
	        {
	            n=n.next;
	        }
	        n.next=null;
	        
	    }
	    void show()
	    {
	        Node1 n=head;
	        while(n.next!=null)
	        {
	            System.out.println(n.data);
	            n=n.next;
	        }
	        System.out.println(n.data);
	        
	    }
	}
	class NodeDemo
	{
	    public static void main(String args[])
	    {
	       SingleLink list=new SingleLink();
	       list.insert(10);
	       list.insert(20);
	       list.insert(30);
	       list.insert(40);
	       list.insert(50);
	       list.insertAtend(60);
	       
	       list.insertbeg(50);
	       list.insertAt(2, 70);
	       //list.deleteAt(3);
	       //list.deleteAtbeg();
	       //list.insertbeg(5);
	       //list.show();
	       
	       list.deleteAtLast();
	       list.insertAtend(90);
	       
	      list.show();
	    }
}
