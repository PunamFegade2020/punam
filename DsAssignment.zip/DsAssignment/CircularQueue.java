package DsAssignment;
import java.util.*; 
class Circular
{ 
    static class Node 
	{ 
		int data; 
		Node n; 
	} 
	static class CircularQueue
	{ 
		Node front, rear; 
	} 
 	static void insert(CircularQueue q, int value) 
	{ 
		Node temp = new Node(); 
		temp.data = value; 
		if (q.front == null) 
		q.front = temp; 
		else
		q.rear.n= temp; 
                                      q.rear = temp; 
		q.rear.n = q.front; 
	} 

	static int delete(CircularQueue q) 
	{ 
		if (q.front == null) 
		{ 
			System.out.printf("Queue is empty"); 
			return Integer.MIN_VALUE; 
		} 
		int value; 
		if (q.front == q.rear) 
		{ 
			value = q.front.data; 
			q.front = null; 
			q.rear = null; 
		} 
		else 
		{ 
			Node temp = q.front; 
			value = temp.data; 
			q.front = q.front.n; 
			q.rear.n = q.front; 
                                      }  

		return value; 
	} 
 
	static void displayQ(CircularQueue q) 
	{ 
		Node temp = q.front; 
		System.out.println("Elements in Circular Queue are: "); 
		while (temp.n != q.front) { 
			System.out.println(+temp.data); 
			temp = temp.n; 
		} 
		System.out.println(temp.data); 
	} 

	public static void main(String args[])
                   {
		CircularQueue q = new CircularQueue(); 
		q.front = q.rear = null; 

		// Inserting elements in Circular Queue 
		insert(q, 14); 
		insert(q, 22); 
		insert(q, 6); 
		displayQ(q);
                
		System.out.println("Deleted element = "+delete(q)); 
		System.out.println("Deleted element = " +delete(q)); 
		displayQ(q); 

		insert(q, 9); 
		insert(q, 20); 
		insert(q,5);
		displayQ(q); 
	} 
} 

