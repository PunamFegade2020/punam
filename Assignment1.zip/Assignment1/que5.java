import java.util.*;
class que4
{
public static void main(String args[])
{
int num1,num2;

int mul;
Scanner sc=new Scanner(System.in);

System.out.println("Input First Number:");
num1=sc.nextInt();
System.out.println("Input Second Number:");
num2=sc.nextInt();

sc.close();
mul=num1*num2;
System.out.println("mul"+mul);
}
}
