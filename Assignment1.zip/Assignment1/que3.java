class que3
{
public static void main(String args[])
{
int num1=50;
int num2=3;
int Div=num1/num2;
System.out.println("Div="+Div);
}
}
