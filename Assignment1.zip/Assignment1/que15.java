class que15
{
public static void main(String args[])
{
int a=10,b=20,t;
t=a;
a=b;
b=t;
System.out.println("Swap the two variable");
System.out.println("a="+a);
System.out.println("b="+b);
}
}
