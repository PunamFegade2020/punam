import java.util.*;
class que12
{
public static void main(String args[])
{
int a,b,c,avg;
Scanner sc=new Scanner(System.in);
System.out.println("Enter the first Numbers");
 a=sc.nextInt();

System.out.println("Enter the second Numbers");
b=sc.nextInt();

System.out.println("Enter the third  Numbers");
c=sc.nextInt();
sc.close();

System.out.println("Average of  3 number=");
int sum=a+b+c;
avg=sum/3;
System.out.println(avg);
}
}