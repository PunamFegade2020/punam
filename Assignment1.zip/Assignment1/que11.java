class que11
{
public static void main(String args[])
{
double pi=3.14;
double r=7.5;
double area,perimeter;

perimeter=2*3.14*r;
System.out.println("Perimeter is="+perimeter);
area=3.14*r*r;
System.out.println("Arae is="+area);
}
}