import java.util.*;
class que6
{
public static void main(String args[])
{
int num1,num2;

int add,sub,mul,div,mod;
Scanner sc=new Scanner(System.in);

System.out.println("Input First Number:");
num1=sc.nextInt();
System.out.println("Input Second Number:");
num2=sc.nextInt();
System.out.println("Expected output: ");

sc.close();
add=num1+num2;
System.out.println(num1+"+"+num2+"="+add);

sub=num1-num2;
System.out.println(num1+"-"+num2+"="+sub);

mul=num1*num2;
System.out.println(num1+"*"+num2+"="+mul);

div=num1/num2;
System.out.println(num1+"/"+num2+"="+div);

mod=num1%num2;
System.out.println(num1+"%"+num2+"="+mod);

}
}
