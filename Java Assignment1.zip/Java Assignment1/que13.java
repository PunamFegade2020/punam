class que13
{
public static void main(String args[])
{
double wid=5.5;
double height=8.5;
double area,perimeter;
area=wid*height;
System.out.println("Area is="+ wid+"*"+height+"="+area);
perimeter=2*(wid+height);
System.out.println("Perimeter is="+2+"*"+wid+"+"+height+"="+perimeter);
}
}