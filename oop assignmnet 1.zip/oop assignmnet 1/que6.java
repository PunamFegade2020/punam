import java.util.*;
class que6
{
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
double pi=3.14;
System.out.println("Enter the radius of circle :");
double r=sc.nextDouble();

sc.close();
double area=3.14*r*r;
System.out.println("Area of circle :"+area);
double circum=2*3.14*r;
System.out.println("Circumference of circle :"+circum);
}
}