import java.util.*;
class que13
{
public static void main(String args[])
{
int a,b,c,large;
Scanner sc=new Scanner(System.in);
System.out.println("Enter 3 numbers :");
a=sc.nextInt();
b=sc.nextInt();
c=sc.nextInt();

large=(a>b)?(a>c?a:c):(b>c?b:c);
System.out.println("Largest number :"+large);
}
}