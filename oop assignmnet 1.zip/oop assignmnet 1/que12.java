import java.util.*;
class que12
{
public static void main(String args[])
{
float basic_salary, da, hra, GrossPayment;
Scanner sc=new Scanner(System.in);
System.out.println("Enter Basic Salary of Employee : ");
basic_salary = sc.nextFloat();
if(basic_salary  <  10000)
{
 hra=(10*basic_salary)/100;
da=(90*basic_salary)/100;
}
else
{
hra=2000;
da=(98*basic_salary)/100;
}
GrossPayment  = basic_salary+da+hra;
System.out.println("Gross Salary of Employee : "+GrossPayment);
}
}
