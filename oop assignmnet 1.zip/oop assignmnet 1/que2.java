class que2
{
public static void main(String args[])
{
int rollno=100;
System.out.println("roll no= "+rollno);
}
}