import java.util.*;
class que5
{
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);

System.out.println("Enter the user name :");
String s=sc.nextLine();

sc.close();
System.out.println("Welcome "+s);
}
}