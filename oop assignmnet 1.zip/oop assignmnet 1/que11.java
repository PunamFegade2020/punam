class que11
{
public static void main(String args[])
{
int a=b;
int b=a;
System.out.println();
}
}