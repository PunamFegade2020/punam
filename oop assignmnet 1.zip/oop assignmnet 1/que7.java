import java.util.*;
class que7
{
    public static void main(String args[])
    {
        int mark[] = new int[5];
        int i;
        float sum=0;
        float perc;
        Scanner scan = new Scanner(System.in);
		
        System.out.print("Enter marks Obtained in 5 Subjects : ");
        for(i=0; i<5; i++)
        {
            mark[i] = scan.nextInt();
            sum = sum + mark[i];
        }
	
        perc = (sum/500) * 100;
		
        System.out.println("Percentage  marks = " +perc+ "%");
    }
}