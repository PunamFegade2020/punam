class que4
{
public static void main(String args[])
{
byte a=10;
byte b=20;
int sum=(a+b);
System.out.println("sum ="+sum);
}
}