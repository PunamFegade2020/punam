import java.util.*;
class que15
{
public static void main(String[] args){
  System.out.println("Enter your age");
  Scanner s1=new Scanner(System.in);
  int age=s1.nextInt();

  if ( age >= 20 ){
    System.out.println( "Your age is 20+ " );
    System.out.println( "Eligible for marriage" );
  }

  else{
    System.out.println( "Your age are not  20" );
    System.out.println( "Not eligible for marriage " );
  }
}
}