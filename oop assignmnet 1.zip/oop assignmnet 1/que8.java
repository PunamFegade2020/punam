import java.util.*;
class que8
{
public static void main(String args[])
{
long p,r;
int t;
double SI;
Scanner sc = new Scanner(System.in);
System.out.println("Enter Principle , Rate of interest & Time");
p = sc.nextLong();
r=sc.nextLong();
t=sc.nextInt();
sc.close();

SI = (p*r*t) /100;
System.out.println("Simple Interest : "+SI);
}
}